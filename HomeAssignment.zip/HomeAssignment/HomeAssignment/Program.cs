﻿
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Linq;
using HomeAssignment.Model;
using Microsoft.VisualBasic.CompilerServices;

/* Gjorde så långt jag hann med, det är ett skript så var svårt att få till tester och hade lite svårt med att hinna med att få in modellen på ett snyggt sätt*/
namespace HomeAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            string order1, order2, order3, xmlFile;

            order1 = "C:/Users/DaraK/source/repos/HomeAssignment/HomeAssignment/Order1.txt";
            order2 = "C:/Users/DaraK/source/repos/HomeAssignment/HomeAssignment/Order2.txt";
            order3 = "C:/Users/DaraK/source/repos/HomeAssignment/HomeAssignment/Order3.txt";
            xmlFile = "C:/Users/DaraK/source/repos/HomeAssignment/HomeAssignment/Orders.xml";

            string[] lines1 = System.IO.File.ReadAllLines(order1);
            string[] lines2 = System.IO.File.ReadAllLines(order2);
            string[] lines3 = System.IO.File.ReadAllLines(order3);



            string[] attributes = lines1[0].Substring(1, lines1[0].Length - 2).Split("|"); //assuming files are formatted the same way

            
            XmlWriter xmlWriter = XmlWriter.Create(xmlFile);

            xmlWriter.WriteStartDocument();
            xmlWriter.WriteComment("Xml-fil för att hantera orders");
            xmlWriter.WriteStartElement("Orders");

            CreateXmlElement(xmlWriter, "Order", lines1, attributes);
            CreateXmlElement(xmlWriter, "Order", lines2, attributes);
            CreateXmlElement(xmlWriter, "Order", lines3, attributes);

            xmlWriter.WriteEndElement();
            xmlWriter.WriteEndDocument();
            xmlWriter.Flush();
            xmlWriter.Close();

            string userOrderNumber = AskUserForOrderNumber();
            string userLineNumber = AskUserForLineOrderNumber();
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(xmlFile);
            XmlNode userRequest = GetSpecifiedOrder(xmlDoc.DocumentElement, userOrderNumber, userLineNumber);
             
            if (userRequest == null)
            {
                Console.WriteLine("No order found");
            }
            else
            {
                Console.Write("|");
                foreach (XmlNode child in userRequest)
                {
                    Console.Write(child.InnerText + "|");
                }
            }
        }

        static void CreateXmlElement(XmlWriter x, string name, string[] lines, string[] att)
        {
            int iter = 0;
            for (int i = 1; i < lines.Length; i++)
            {
                x.WriteStartElement(name);
                foreach (string s in lines[i].Substring(1, lines[i].Length - 2).Split("|"))
                {
                    x.WriteElementString(lines[0].Substring(1, lines[0].Length - 2).Split("|")[iter++ % att.Length], s);
                }
                x.WriteEndElement();
            }
        }
        /*
        static OrderModel createOrder(string line, string[] att)
        {
            int i = 0;
            List<OrderModel> temp = new List<OrderModel>();
            List<string> str = new List<string>();
            foreach (string l in line.Substring(1, line.Length - 2).Split("|"))
            {
                str.Add(l);
            }
            return new OrderModel(
                {
                OrderNumber = int.Parse(str[0]),
                OrderLineNumber = str[1],
                ProductNumber = str[2],


            })
        }
        */
        static string AskUserForOrderNumber()
        {
            Console.WriteLine("Type order number: 5 digits");
            string userInput = Console.ReadLine();
            while (userInput.Length != 5)
            {
                Console.WriteLine("Not 5 digits, try again.");
                userInput = Console.ReadLine();
            }
            return userInput;
        }
        static string AskUserForLineOrderNumber()
        {
            Console.WriteLine("Type order line number: 4 digits");
            string userInput = Console.ReadLine();
            while (userInput.Length != 4)
            {
                Console.WriteLine("Not 4 digits, try again");
                userInput = Console.ReadLine();
            }
            return userInput;
        }
        static XmlNode GetSpecifiedOrder(XmlNode x, string userOrderNumber, string userLineNumber)
        {
            
            List<XmlNode> parentElements = new List<XmlNode>();
            foreach (XmlNode node in x)
            {
                foreach (XmlNode child in node)
                {
                    if (child.Name == "OrderNumber" && child.InnerText == userOrderNumber)
                    {
                        parentElements.Add(node);
                    }
                }
            }
            foreach (XmlNode node in parentElements)
            {
                foreach (XmlNode child in node)
                {
                    if (child.Name == "OrderLineNumber" && child.InnerText == userLineNumber)
                    {
                        return node;
                    }
                }
            }
            return null;

        }
    }
}
